package com.example.classRoomaAPPv3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassRoomaApPv3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
